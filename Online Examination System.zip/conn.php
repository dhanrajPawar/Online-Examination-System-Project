<?php 

$host = "localhost";
$user = "root";
$pass = "";
$db   = "dsp";
$conn = null;

try {
  $conn = new PDO("mysql:host={$host};dbname={$db};",$user,$pass);
} catch (Exception $e) {
  
}


 ?>